import{M as t}from"./masonry-DMJWjakW.js";new t(".news-list__items",{itemSelector:".news-list__items__item",columnWidth:".news-list__items__item",percentPosition:!0,transitionDuration:"0.2"});
